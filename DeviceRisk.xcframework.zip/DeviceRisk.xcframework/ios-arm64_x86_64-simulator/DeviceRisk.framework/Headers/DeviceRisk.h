//
//  DeviceRisk.h
//  DeviceRisk
//
//  Created by Nicolas Dedual on 7/20/20.
//  Copyright © 2020 Socure. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for DeviceRisk.
FOUNDATION_EXPORT double DeviceRiskVersionNumber;

//! Project version string for DeviceRisk.
FOUNDATION_EXPORT const unsigned char DeviceRiskVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DeviceRisk/PublicHeader.h>


